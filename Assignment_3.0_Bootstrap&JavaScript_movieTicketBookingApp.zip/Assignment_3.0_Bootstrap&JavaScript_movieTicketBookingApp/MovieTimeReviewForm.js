//UILayer
var UIlayer = {
    txtBox: {
        nameTxtBox: document.querySelector("#nameTxtBox"),
        ageTxtBox: document.querySelector("#ageTxtBox"),
        emailTxtBox: document.querySelector("#emailTxtBox"),
        phoneNoTxtBox: document.querySelector("#phoneNoTxtBox"),
        audiNoTxtBox: document.querySelector("#audiNoTxtBox")
    },
    form: document.querySelector("form"),
    validationMsgArr: document.querySelectorAll(".validationMsg"),
    date: document.querySelector("#showDate")
}

// Logic Layer
for (ele in UIlayer.txtBox) {
    UIlayer.txtBox[ele].addEventListener("keypress", validateKeys);
    UIlayer.txtBox[ele].addEventListener("focusout", hideValidationMsg)
}

UIlayer.date.value = new Date().toISOString().substr(0, 10);
UIlayer.form.onsubmit = validateMandatoryFields;

function validateKeys() {
    var txtBox = this,
        keyCode = event.keyCode,
        validationMsg = txtBox.parentElement.querySelector(".validationMsg"),
        invalidChar = false,
        preventDefault = false;
    switch (txtBox) {
        case nameTxtBox:
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && keyCode !== 32 && keyCode !== 46) {
                invalidChar = true;
                preventDefault = true;
            }
            break;
        case ageTxtBox:
            if (isNaN(event.key)) {
                invalidChar = true;
                preventDefault = true;
                break;
            }
            if (txtBox.value) {
                var value = (txtBox.value * 10) + Number(event.key);
                if (value > 120) {
                    txtBox.value = 120;
                    invalidChar = false;
                    preventDefault = true;
                }
            }
            break;
        case phoneNoTxtBox:
            if (isNaN(event.key)) {
                invalidChar = true;
                preventDefault = true;
                break;
            }
            if (txtBox.value.length >= 10) {
                invalidChar = false;
                preventDefault = true;
            }
            break;
        case emailTxtBox:
            if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (isNaN(event.key)) && keyCode !== 46 && keyCode !== 64) {
                invalidChar = true;
                preventDefault = true;
            }
            break;
        case audiNoTxtBox:
            if (isNaN(event.key)) {
                invalidChar = true;
                preventDefault = true;
                break;
            }
            if ((event.key > 5 || event.key < 1) || txtBox.value.length !== 0) {
                txtBox.value = 1;
                invalidChar = false;
                preventDefault = true;
            }
        default: break;

    }
    if (invalidChar) {
        validationMsg.style.visibility = "visible";
    }
    preventDefault && event.preventDefault();
}

function hideValidationMsg() {
    var _this = this;
    UIlayer.validationMsgArr.forEach(function (ele) {
        ele.style.visibility = "hidden";
    });
    if (_this === UIlayer.txtBox.phoneNoTxtBox) {
        validatePhoneNo(_this);
    }
    if (_this === UIlayer.txtBox.ageTxtBox) {
        validateAgeTxtBox(_this);
    }
    if (_this === UIlayer.txtBox.audiNoTxtBox) {
        validateAudiNoTxtBox(_this);
    }
}

function validateAgeTxtBox(ageTxtBox) {
    var validationMsg = ageTxtBox.parentElement.querySelector(".validationMsg");
    if (ageTxtBox.value && (ageTxtBox.value < 10 || ageTxtBox.value > 120)) {
        validationMsg.style.visibility = "visible";
        return false;
    } else {
        return true;
    }
}

function validateAudiNoTxtBox(audiNoTxtBox) {
    var validationMsg = audiNoTxtBox.parentElement.querySelector(".validationMsg");
    if (ageTxtBox.value && (ageTxtBox.value < 1 || ageTxtBox.value > 5)) {
        validationMsg.style.visibility = "visible";
        return false;
    } else {
        return true;
    }
}

function validatePhoneNo(phoneNoTxtBox) {
    if (phoneNoTxtBox.value && phoneNoTxtBox.value.length !== 10) {
        phoneNoTxtBox.parentElement.querySelector(".validationMsg").style.visibility = "visible";
        return false;
    } else {
        return true;
    }
}

function validateMandatoryFields() {
    if (!(UIlayer.txtBox.nameTxtBox.value && UIlayer.txtBox.ageTxtBox.value && UIlayer.txtBox.emailTxtBox.value && UIlayer.txtBox.phoneNoTxtBox.value)) {
        alert("Please Fill all the fields which are marked mandatory!!!");
        return false;
    }
    if (!validatePhoneNo(UIlayer.txtBox.phoneNoTxtBox)) {
        return false;
    }
    if (!validateAgeTxtBox(UIlayer.txtBox.ageTxtBox)) {
        return false;
    }
}




