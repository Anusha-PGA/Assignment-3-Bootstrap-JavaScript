//UILayer
var UIlayer = {
    btn: {
        addBtn: document.querySelector("#addWishBtn"),
        saveBtn: document.querySelector("#saveBtn")
    },
    welcomeHeading: document.querySelector("h1"),
    table: {
        wishListTable: document.querySelector("#wishListTable")
    },
    txtBox: {
        wishName: document.querySelector("#wishName"),
        wishDesc: document.querySelector("#wishDesc")
    },
    wishListModel: $("#WistListModal"),
    validationMsg: document.querySelector(".validationMsg"),
    logOutIcon: document.querySelector("#logOutIcon")
}

// Logic Layer
setWelcomeMsg();
showTable();

UIlayer.btn.addBtn.addEventListener("click", showDialog);
UIlayer.logOutIcon.addEventListener("click", logOut);

function setWelcomeMsg() {
    var emailId = localStorage.getItem("loginedUser"),
        usersDetails = JSON.parse(localStorage.getItem("userDetails")),
        userName;
    usersDetails.forEach(function (user) {
        if (user.emailId === emailId) {
            userName = user.name;
        }
    });
    UIlayer.welcomeHeading.innerHTML += " " + userName;
}

function showTable() {
    var emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        user;
    //wishList = userDetails.wishList;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    if (userDetails[user].wishList.length > 0) {
        UIlayer.table.wishListTable.style.visibility = "visible";
        constructTable();
    } else {
        UIlayer.table.wishListTable.style.visibility = "hidden";
    }
}

function addWish() {
    var newWish = {
        wishName: UIlayer.txtBox.wishName.value,
        wishDesc: UIlayer.txtBox.wishDesc.value,
        items: []
    },
        emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        user;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    userDetails[user].wishList.push(newWish);
    localStorage.setItem("userDetails", JSON.stringify(userDetails));/*  */
    showTable();
}

function constructTable() {
    var emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        table = UIlayer.table.wishListTable,
        rowCount = table.rows.length,
        user;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var wishList = userDetails[user].wishList;
    for (var x = rowCount - 1; x > 0; x--) {
        table.deleteRow(x);
    }
    if (wishList.length) {
        for (var i in wishList) {
            var wishName = wishList[i].wishName;
            var wishDesc = wishList[i].wishDesc;
            var row = table.insertRow(-1);
            var cell_wishName = row.insertCell(0);
            var cell_wishDesc = row.insertCell(1);
            var cell_delBtn = row.insertCell(2);
            var cell_updateBtn = row.insertCell(3);

            var wishNameLink = document.createElement("a");
            wishNameLink.setAttribute("href", "WishListDescriptionPage.html");
            wishNameLink.setAttribute("onclick", "cacheSelectedWishName(this)");
            wishNameLink.innerHTML = wishName;

            var deletebtn = document.createElement("BUTTON");
            deletebtn.setAttribute("class", "form-control Btn");
            deletebtn.innerHTML = "Delete";

            var updateBtn = document.createElement("BUTTON");
            updateBtn.setAttribute("class", "form-control Btn");
            updateBtn.innerHTML = "Edit";

            deletebtn.setAttribute("onclick", "deleteWish(this)");

            updateBtn.setAttribute("onclick", "showDialogEdit(this)");

            cell_wishName.appendChild(wishNameLink);
            cell_wishDesc.innerHTML = wishDesc;
            cell_delBtn.appendChild(deletebtn);
            cell_updateBtn.appendChild(updateBtn);
        }
    }
}

function cacheSelectedWishName(_this) {
    localStorage.setItem("SelectedWishName", _this.innerText);
}

function deleteWish(_this) {
    var wishName = _this.parentElement.parentElement.querySelector("a").innerHTML,
        emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        user,

        selectedWishIndex;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var wishList = userDetails[user].wishList;
    for (var i = 0; i < wishList.length; i++) {
        if (wishList[i].wishName === wishName) {
            selectedWishIndex = i;
        }
    }
    userDetails[user].wishList.splice(selectedWishIndex, 1);
    localStorage.setItem("userDetails", JSON.stringify(userDetails));
    showTable();
}



function save() {
    var wishName = UIlayer.txtBox.wishName.value,
        wishDesc = UIlayer.txtBox.wishDesc.value;
    if ((wishName && wishDesc)) {
        UIlayer.wishListModel.modal('hide');
        UIlayer.validationMsg.style.visibility = "hidden";
        addWish();
    } else {
        UIlayer.validationMsg.style.visibility = "visible";
    }

}

function showDialog() {
    UIlayer.btn.saveBtn.removeEventListener("click", function () { });
    UIlayer.txtBox.wishName.value = "";
    UIlayer.txtBox.wishDesc.value = ""
    UIlayer.wishListModel.modal('show');
    UIlayer.btn.saveBtn.addEventListener("click", save);
}

function showDialogEdit(_this) {
    UIlayer.btn.saveBtn.removeEventListener("click", save);
    var emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        user;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var wishList = userDetails[user].wishList,
        selectedWishName = _this.parentElement.parentElement.firstElementChild.innerText,
        selectedWishIndex;
    for (var i = 0; i < wishList.length; i++) {
        if (wishList[i].wishName === selectedWishName) {
            selectedWishIndex = i;
        }
    }
    UIlayer.txtBox.wishName.value = userDetails[user].wishList[selectedWishIndex].wishName;
    UIlayer.txtBox.wishDesc.value = userDetails[user].wishList[selectedWishIndex].wishDesc;
    UIlayer.btn.saveBtn.addEventListener("click", function () { updateChanges(userDetails, user, selectedWishIndex) });
    UIlayer.wishListModel.modal('show');
}

function updateChanges(userDetails, user, selectedWishIndex) {
    var editedItem = {
        wishName: UIlayer.txtBox.wishName.value,
        wishDesc: UIlayer.txtBox.wishDesc.value,
        items: userDetails[user].wishList[selectedWishIndex].items
    };
    userDetails[user].wishList[selectedWishIndex] = editedItem;
    localStorage.setItem("userDetails", JSON.stringify(userDetails));
    UIlayer.wishListModel.modal('hide');
    showTable();
}

function logOut(){
    localStorage.removeItem("loginedUser");
}

