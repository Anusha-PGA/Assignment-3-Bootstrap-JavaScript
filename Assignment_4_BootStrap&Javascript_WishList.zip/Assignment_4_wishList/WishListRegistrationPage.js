//UILayer
var UIlayer = {
        txtBox: {
            userNameTxtBox: document.querySelector("#userNameTxtBox"),
            emailTxtBox: document.querySelector("#emailTxtBox"),
            passWordTxtBox: document.querySelector("#passWordTxtBox"),
        },
        form: document.querySelector("form"),
        validationMsgArr: document.querySelectorAll(".validationMsg")
    }
    
    // Logic Layer
    for (ele in UIlayer.txtBox) {
        UIlayer.txtBox[ele].addEventListener("keypress", validateKeys);
        UIlayer.txtBox[ele].addEventListener("focusout", hideValidationMsg)
    }
    
    UIlayer.form.onsubmit = validateMandatoryFields;
    
    function validateKeys() {
        var txtBox = this,
            keyCode = event.keyCode,
            validationMsg = txtBox.parentElement.querySelector(".validationMsg"),
            invalidChar = false,
            preventDefault = false,
            validationMsgStr = "";
        switch (txtBox) {
            case userNameTxtBox:
                if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && keyCode !== 32 && keyCode !== 46) {
                    invalidChar = true;
                    preventDefault = true;
                    validationMsgStr = "Enter only alphabets"
                }
                break;
            case emailTxtBox:
                if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (isNaN(event.key)) && keyCode !== 46 && keyCode !== 64) {
                    invalidChar = true;
                    preventDefault = true;
                    validationMsgStr = "Enter only valid characters"
                }
                break;
            default: break;
    
        }
        if (invalidChar) {
            validationMsg.style.visibility = "visible";
            validationMsg.innerHTML = validationMsgStr;
        } else {
            if (validationMsg) {
                validationMsg.style.visibility = "hidden";
            }
        }
        preventDefault && event.preventDefault();
    }
    
    function hideValidationMsg() {
        UIlayer.validationMsgArr.forEach(function (ele) {
            ele.style.visibility = "hidden";
        });
    }
    
    function validateMandatoryFields() {
        if (!(UIlayer.txtBox.userNameTxtBox.value && UIlayer.txtBox.emailTxtBox.value && UIlayer.txtBox.passWordTxtBox.value)) {
            alert("Please Fill all the fields !!!");
            return false;
        }
        var isEmailValid = checkIfEmailIsValid();
        if (isEmailValid) {
            regiterUserDetails();
        } else {
            return false;
        }
    }
    
    function checkIfEmailIsValid() {
        var usersDetails = JSON.parse(localStorage.getItem("userDetails")) || [],
            emailId = UIlayer.txtBox.emailTxtBox.value,
            isValid = true;
        if (usersDetails.length > 0) {
            usersDetails.forEach(function (user) {
                if (user.emailId === emailId) {
                    alert("This " + emailId + " email Id is already registered with us!!! Please try giving another one");
                    emailId.value = "";
                    isValid= false;
                }
            });
        }
        return isValid;
    }
    
    function regiterUserDetails() {
        var usersDetails = JSON.parse(localStorage.getItem("userDetails")) || [],
            userDetailsObj = {
                name: UIlayer.txtBox.userNameTxtBox.value,
                emailId: UIlayer.txtBox.emailTxtBox.value,
                password: UIlayer.txtBox.passWordTxtBox.value,
                wishList: []
            }
        usersDetails.push(userDetailsObj);
        localStorage.setItem("userDetails", JSON.stringify(usersDetails));
        alert("Registered Sucessfully...")
    }    