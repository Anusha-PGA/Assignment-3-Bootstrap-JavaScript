//UILayer
var UIlayer = {
    txtBox: {
        emailTxtBox: document.querySelector("#emailTxtBox"),
        passWordTxtBox: document.querySelector("#passWordTxtBox"),
    },
    form: document.querySelector("form"),
    validationMsg: document.querySelector(".validationMsg")
}

// Logic Layer
UIlayer.txtBox.emailTxtBox.addEventListener("keypress", validateKeys);
UIlayer.txtBox.emailTxtBox.addEventListener("focusout", hideValidationMsg)
UIlayer.form.onsubmit = validateMandatoryFields;
(function () {
    var loginedUser = localStorage.getItem("loginedUser");
    UIlayer.txtBox.emailTxtBox.value = loginedUser || "";
})();

function validateKeys() {
    var txtBox = this,
        keyCode = event.keyCode,
        validationMsg = txtBox.parentElement.querySelector(".validationMsg"),
        invalidChar = false,
        preventDefault = false,
        validationMsgStr = "";
    if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (isNaN(event.key)) && keyCode !== 46 && keyCode !== 64) {
        invalidChar = true;
        preventDefault = true;
        validationMsgStr = "Enter only valid characters"
    }
    if (invalidChar) {
        validationMsg.style.visibility = "visible";
        validationMsg.innerHTML = validationMsgStr;
    } else {
        validationMsg.style.visibility = "hidden"
    }
    preventDefault && event.preventDefault();
}

function hideValidationMsg() {
    UIlayer.validationMsg.style.visibility = "hidden";
}


function validateMandatoryFields() {
    if (!(UIlayer.txtBox.emailTxtBox.value && UIlayer.txtBox.passWordTxtBox.value)) {
        alert("Please Fill all the fields !!!");
        return false;
    }
    var isUserValid = checkIfValidUsers();
    if (!isUserValid) {
        alert("You have entered wrong email Id or password!!!");
        return false;
    }
    localStorage.setItem("loginedUser", emailTxtBox.value);
}

function checkIfValidUsers() {
    var usersDetails = JSON.parse(localStorage.getItem("userDetails")) || [],
        emailId = UIlayer.txtBox.emailTxtBox.value,
        password = UIlayer.txtBox.passWordTxtBox.value,
        isValid = false;
    if (usersDetails.length > 0) {
        usersDetails.forEach(function (user) {
            if (user.emailId === emailId) {
                if (password === user.password) {
                    isValid = true;
                }
            }
        });
    }
    return isValid;
}

function handleBackBtn() {
    
}



