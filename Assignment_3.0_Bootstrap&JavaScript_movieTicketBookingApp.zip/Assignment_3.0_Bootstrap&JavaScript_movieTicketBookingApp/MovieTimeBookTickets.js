//UI Layer
var UIlayer = {
    select: {
        movieTitleSelect: document.querySelector("#movieTitleSelect"),
        theaterNameSelect: document.querySelector("#theaterNameSelect"),
        showTimeSelect: document.querySelector("#showTimeSelect"),
    },
    checkBoxArr: document.querySelectorAll("input[type=checkbox]"),
    date: document.querySelector("#showDate"),
    form: document.querySelector("form"),
    totalAmtTxtBox: document.querySelector("#totalAmtTxtBox")
}
// Logic Layer

var selectedSeatsCounter = 0
UIlayer.totalAmtTxtBox.innerHTML = "Rs : 0";
initializeDateElement();
UIlayer.form.onsubmit = bookTickets;

function initializeDateElement() {
    var currentDate = new Date(),
        dd = currentDate.getDate() + 7,
        mm = currentDate.getMonth() + 1,
        yyyy = currentDate.getFullYear();
    if (dd < 10) {
        dd = '0' + dd
    }
    if (mm < 10) {
        mm = '0' + mm
    }
    var maxDate = yyyy + '-' + mm + '-' + dd;
    UIlayer.date.value = currentDate.toISOString().substr(0, 10);
    UIlayer.date.setAttribute("min", currentDate.toISOString().substr(0, 10));
    UIlayer.date.setAttribute("max", maxDate);
}


UIlayer.checkBoxArr.forEach(function (ele) {
    ele.addEventListener("click", selectSeats);
});

function selectSeats() {
    if (this.checked === true) {
        selectedSeatsCounter += 1;
    } else {
        selectedSeatsCounter -= 1;
    }
    if (selectedSeatsCounter > 5) {
        alert("Maximum number of seated that can be selected is 5");
        this.checked = false;
        selectedSeatsCounter -= 1;
    }
    calculateTotalAmt(selectedSeatsCounter);
}

function calculateTotalAmt(totalSeats) {
    var totalAmt = 245 * totalSeats;
    UIlayer.totalAmtTxtBox.innerHTML = "Rs : " + totalAmt;

}

function bookTickets() {
    if (selectedSeatsCounter < 1) {
        alert("Please select the seats and then click Book!!!!")
        return false;
    }
}
