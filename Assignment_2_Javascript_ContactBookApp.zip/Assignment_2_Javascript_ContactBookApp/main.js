var UILayer = {
    txtBox: {
        nameTxtBox: document.querySelector("#nameTxtBox"),
        mobileTxtBox: document.querySelector("#mobileTxtBox"),
        emailTxtBox: document.querySelector("#emailTxtBox"),
        searchContactTxtBox: document.querySelector("#searchContact")
    },
    btn: {
        addBtn: document.querySelector("#addBtn"),
        cancelBtn: document.querySelector("#cancelBtn"),
    },
    tableDiv: document.querySelector(".tableDiv"),
    contactDetailsForm: document.querySelector("#contactDetailsForm")
}

var contacts = [
    { "name": "Anusha", "email": "anusha.pga@gmail.com", "mobile": "8197810294" },
    { "name": "Wall-E", "email": "walle@gmail.com", "mobile": "8197810294" },
    { "name": "Eva", "email": "eva.pga@gmail.com", "mobile": "8197810294" }
];

UILayer.btn.addBtn.addEventListener("click", addContact);
UILayer.txtBox.searchContactTxtBox.addEventListener("keyup", searchContact);
UILayer.txtBox.searchContactTxtBox.addEventListener("focusout", function () {
    showTable(contacts);
});

var rowIndex;
showTable(contacts);

function showTable(_contacts) {
    var table = "<table class='contactsTable'>";
    table += "<tr><th>Name</th><th>Mobile number</th><th>Email Id</th><th>Edit</th></tr>";
    _contacts.forEach(function (contact) {
        table += `<tr><td>${contact.name}</td><td>${contact.mobile}</td><td>${contact.email}</td><td><input type="button" value="Edit" id="editBtn" onclick="edit(this)"> <input type="button" value="Delete" id="delBtn" onclick="deleteContact(this)">  `;
    });
    table += "</table>";
    UILayer.tableDiv.innerHTML = table;
}

function addContact() {
    if (UILayer.txtBox.nameTxtBox.value && UILayer.txtBox.mobileTxtBox.value && UILayer.txtBox.emailTxtBox.value) {
        var newContact = {
            name: UILayer.txtBox.nameTxtBox.value,
            mobile: UILayer.txtBox.mobileTxtBox.value,
            email: UILayer.txtBox.emailTxtBox.value
        }
        contacts.push(newContact);
        showTable(contacts);
        UILayer.contactDetailsForm.reset();
    } else {
        alert("Please fill all the Details");
    }
}

function edit(_this) {
    UILayer.btn.addBtn.value = "Update";
    UILayer.btn.cancelBtn.style.display = "inline-block";
    rowIndex = Number(_this.parentElement.parentElement.rowIndex) - 1;
    obj = contacts[rowIndex];
    UILayer.txtBox.nameTxtBox.value = obj.name;
    UILayer.txtBox.mobileTxtBox.value = obj.email;
    UILayer.txtBox.emailTxtBox.value = obj.mobile;
    UILayer.btn.addBtn.removeEventListener("click", addContact);
    UILayer.btn.addBtn.addEventListener("click", updateContact);
    document.querySelector("#cancelBtn").addEventListener("click", cancelUpdation);
}

function updateContact() {
    var updatedContact = {
        name: UILayer.txtBox.nameTxtBox.value,
        mobile: UILayer.txtBox.mobileTxtBox.value,
        email: UILayer.txtBox.emailTxtBox.value
    }
    contacts[rowIndex] = updatedContact;
    showTable(contacts);
    UILayer.btn.addBtn.removeEventListener("click", updateContact);
    UILayer.btn.addBtn.addEventListener("click", addContact);
    UILayer.contactDetailsForm.reset();
    UILayer.btn.addBtn.value = "Add Contact";
    UILayer.btn.cancelBtn.style.display = "none";
}

function cancelUpdation() {
    UILayer.btn.addBtn.removeEventListener("click", updateContact);
    UILayer.btn.addBtn.addEventListener("click", addContact);
    UILayer.btn.addBtn.value = "Add Contact";
    UILayer.contactDetailsForm.reset();
    UILayer.btn.cancelBtn.style.display = "none";
}

function deleteContact(_this) {
    rowIndex = Number(_this.parentElement.parentElement.rowIndex) - 1;
    contacts.splice(rowIndex, 1);
    showTable(contacts);
    localStorage.setItem("")
}

function searchContact(keyPressed) {
    if (keyPressed.key === "Enter") {
        var searchStr = UILayer.txtBox.searchContactTxtBox.value,
            searchResult = [];
        contacts.forEach(function (contact) {
            var str = contact.name.toLowerCase()
            if (str.includes(searchStr)) {
                searchResult.push(contact);
            }
        });
        if (searchResult.length > 0) {
            showTable(searchResult);
        }
        else {
            UILayer.tableDiv.innerHTML = "Sorry...No results Found!!!"
        }
    }
}
