//UILayer
var UIlayer = {
    btn: {
        addBtn: document.querySelector("#addItemBtn"),
        saveBtn: document.querySelector("#saveBtn")
    },
    welcomeHeading: document.querySelector("h1"),
    table: {
        wishListItemTable: document.querySelector("#wishListItemTable")
    },
    txtBox: {
        itemName: document.querySelector("#itemName"),
        itemDesc: document.querySelector("#itemDesc"),
        itemLink: document.querySelector("#itemLink")
    },
    RadioBtn: {
        fullFilledRBtn: document.querySelector("#fullFilledRBtn"),
        notYetRbtn: document.querySelector("#notYetRbtn")
    },
    wishListItemModel: $("#WistListItemModal"),
    validationMsg: document.querySelector(".validationMsg"),
    logOutIcon: document.querySelector("#logOutIcon")
}

// Logic Layer
setWelcomeMsg();
showTable();

UIlayer.btn.addBtn.addEventListener("click", showDialog);
UIlayer.logOutIcon.addEventListener("click", logOut);

function setWelcomeMsg() {
    var emailId = localStorage.getItem("loginedUser"),
        usersDetails = JSON.parse(localStorage.getItem("userDetails")),
        userName;
    usersDetails.forEach(function (user) {
        if (user.emailId === emailId) {
            userName = user.name;
        }
    });
    UIlayer.welcomeHeading.innerHTML += " " + userName;
}

function showTable() {
    var emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        user;
    //wishList = userDetails.wishList;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var wishList = userDetails[user].wishList,
        selectedWishName = localStorage.getItem("SelectedWishName"),
        selectedWishItems;
    wishList.forEach(function (wish) {
        if (wish.wishName === selectedWishName) {
            selectedWishItems = wish.items;
        }
    });
    if (selectedWishItems.length > 0) {
        UIlayer.table.wishListItemTable.style.visibility = "visible";
        constructTable();
    } else {
        UIlayer.table.wishListItemTable.style.visibility = "hidden";
    }
}

function addItem() {
    var newItem = {
        itemName: UIlayer.txtBox.itemName.value,
        itemDesc: UIlayer.txtBox.itemDesc.value,
        itemLink: UIlayer.txtBox.itemLink.value,
        itemStatus: UIlayer.RadioBtn.fullFilledRBtn.checked ? "Full filled" : "Not yet"
    },
        emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        user;
    //wishList = userDetails.wishList;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var wishList = userDetails[user].wishList,
        selectedWishName = localStorage.getItem("SelectedWishName"),
        selectedWishItemsIndex;
    for (var i = 0; i < wishList.length; i++) {
        if (wishList[i].wishName === selectedWishName) {
            selectedWishItemsIndex = i;
        }
    }
    userDetails[user].wishList[selectedWishItemsIndex].items.push(newItem);
    localStorage.setItem("userDetails", JSON.stringify(userDetails));
    showTable();
}

function constructTable() {
    var emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        user;
    //wishList = userDetails.wishList;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var table = UIlayer.table.wishListItemTable,
        rowCount = table.rows.length,
        wishList = userDetails[user].wishList,
        selectedWishName = localStorage.getItem("SelectedWishName"),
        selectedWishItemsIndex;
    for (var i = 0; i < wishList.length; i++) {
        if (wishList[i].wishName === selectedWishName) {
            selectedWishItemsIndex = i;
        }
    }
    var itemList = userDetails[user].wishList[selectedWishItemsIndex].items;
    for (var x = rowCount - 1; x > 0; x--) {
        table.deleteRow(x);
    }
    if (itemList.length) {
        for (var i in itemList) {
            var itemName = itemList[i].itemName;
            itemDesc = itemList[i].itemDesc,
                itemLink = itemList[i].itemLink,
                itemStatus = itemList[i].itemStatus,
                row = table.insertRow(-1),
                cell_itemName = row.insertCell(0),
                cell_itemDesc = row.insertCell(1),
                cell_itemLink = row.insertCell(2),
                cell_itemStatus = row.insertCell(3),
                cell_delBtn = row.insertCell(4),
                cell_editBtn = row.insertCell(5);

            var itemLinkEle = document.createElement("a");
            itemLinkEle.setAttribute("href", itemLink);
            itemLinkEle.innerHTML = "Buy";

            var deleteBtn = document.createElement("BUTTON");
            deleteBtn.setAttribute("class", "form-control Btn");
            deleteBtn.innerHTML = "Delete";

            var editBtn = document.createElement("BUTTON");
            editBtn.setAttribute("class", "form-control Btn");
            editBtn.innerHTML = "Edit";

            deleteBtn.setAttribute("onclick", "deleteItem(this)");

            editBtn.setAttribute("onclick", "showDialogEdit(this)");

            cell_itemName.innerHTML = itemName;
            cell_itemDesc.innerHTML = itemDesc;
            cell_itemLink.appendChild(itemLinkEle);
            cell_itemStatus.innerHTML = itemStatus;
            cell_delBtn.appendChild(deleteBtn);
            cell_editBtn.appendChild(editBtn);
        }
    }
}

function cacheSelectedWishName(_this) {
    localStorage.setItem("SelectedWishName", _this.innerText);
}

function deleteItem(_this) {
    var emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        itemName = _this.parentElement.parentElement.firstElementChild.innerText,
        user;
    //wishList = userDetails.wishList;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var wishList = userDetails[user].wishList,
        selectedWishName = localStorage.getItem("SelectedWishName"),
        selectedWishIndex;
    for (var i = 0; i < wishList.length; i++) {
        if (wishList[i].wishName === selectedWishName) {
            selectedWishIndex = i;
        }
    }
    var itemList = userDetails[user].wishList[selectedWishIndex].items,
        selectedItemIndex;
    for (var i = 0; i < itemList.length; i++) {
        if (itemList[i].itemName === itemName) {
            selectedItemIndex = i;
        }
    }
    userDetails[user].wishList[selectedWishIndex].items.splice(selectedItemIndex, 1);
    localStorage.setItem("userDetails", JSON.stringify(userDetails));
    showTable();
}

function save() {
    var itemName = UIlayer.txtBox.itemName.value,
        itemDesc = UIlayer.txtBox.itemDesc.value,
        itemLink = UIlayer.txtBox.itemLink.value;
    if ((itemName && itemDesc && itemLink)) {
        UIlayer.wishListItemModel.modal('hide');
        UIlayer.validationMsg.style.visibility = "hidden";
        addItem();
    } else {
        UIlayer.validationMsg.style.visibility = "visible";
    }

}

function showDialog() {
    UIlayer.btn.saveBtn.removeEventListener("click", function (){});
    UIlayer.txtBox.itemName.value = "";
    UIlayer.txtBox.itemDesc.value = "";
    UIlayer.txtBox.itemLink.value = "";
    UIlayer.wishListItemModel.modal('show');
    UIlayer.btn.saveBtn.addEventListener("click", save);
}

function showDialogEdit(_this) {
    UIlayer.btn.saveBtn.removeEventListener("click", save);
    var emailId = localStorage.getItem("loginedUser"),
        userDetails = JSON.parse(localStorage.getItem("userDetails")),
        itemName = _this.parentElement.parentElement.firstElementChild.innerText,
        user;
    for (var i = 0; i < userDetails.length; i++) {
        if (userDetails[i].emailId === emailId) {
            user = i;
        }
    }
    var wishList = userDetails[user].wishList,
        selectedWishName = localStorage.getItem("SelectedWishName"),
        selectedWishIndex;
    for (var i = 0; i < wishList.length; i++) {
        if (wishList[i].wishName === selectedWishName) {
            selectedWishIndex = i;
        }
    }
    var itemList = userDetails[user].wishList[selectedWishIndex].items,
        selectedItemIndex;
    for (var i = 0; i < itemList.length; i++) {
        if (itemList[i].itemName === itemName) {
            selectedItemIndex = i;
        }
    }
    UIlayer.txtBox.itemName.value = userDetails[user].wishList[selectedWishIndex].items[selectedItemIndex].itemName;
    UIlayer.txtBox.itemDesc.value = userDetails[user].wishList[selectedWishIndex].items[selectedItemIndex].itemDesc;
    UIlayer.txtBox.itemLink.value = userDetails[user].wishList[selectedWishIndex].items[selectedItemIndex].itemLink;
    if (userDetails[user].wishList[selectedWishIndex].items[selectedItemIndex].itemStatus === "Not yet") {
        UIlayer.RadioBtn.notYetRbtn.checked = true;
        UIlayer.RadioBtn.fullFilledRBtn.checked = false;
    } else {
        UIlayer.RadioBtn.fullFilledRBtn.checked = true;
        UIlayer.RadioBtn.notYetRbtn.checked = false;
    }
    UIlayer.btn.saveBtn.addEventListener("click", function () { updateChanges(userDetails, user, selectedWishIndex, selectedItemIndex) });
    UIlayer.wishListItemModel.modal('show');
}

function updateChanges(userDetails, user, selectedWishIndex, selectedItemIndex) {
    var editedItem = {
        itemName: UIlayer.txtBox.itemName.value,
        itemDesc: UIlayer.txtBox.itemDesc.value,
        itemLink: UIlayer.txtBox.itemLink.value,
        itemStatus: UIlayer.RadioBtn.fullFilledRBtn.checked ? "Full filled" : "Not yet"
    };
    userDetails[user].wishList[selectedWishIndex].items[selectedItemIndex] = editedItem;
    localStorage.setItem("userDetails", JSON.stringify(userDetails));
    UIlayer.wishListItemModel.modal('hide');
    showTable();
}
function logOut(){
    localStorage.removeItem("loginedUser");
}
